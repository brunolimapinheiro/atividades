# [Fazer encurtador de url com PHP e migre.me](http://nandomoreira.me/2012/12/22/fazer-encurtador-de-url-com-php-e-migre-me/)


## License

[MIT](/LICENSE)
