
    <?php echo "o valor digitado foi: ". $_POST["busca"]; ?> 

  
   

