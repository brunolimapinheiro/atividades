class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    Conta conta1= new Conta();
    conta1.numero=1;
    conta1.saldo= 1000;
    conta1.titular="bruno";
   
    System.out.println(conta1.saldo);
    boolean deCerto=conta1.sacar(50);
    if(deCerto){
      System.out.println("sucesso");
  }  else{
      System.out.println("falha");
}
}
}