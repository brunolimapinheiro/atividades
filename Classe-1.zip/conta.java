class Conta{
  int numero;
  String titular;
  double saldo;

  boolean sacar(double valor){
   if(valor<saldo){
     saldo-=valor;
     return true;
}
    else{
      return false;
}

    
    

  void transferir(double valor,Conta destino){
  if(sacar(valor)){
    destino.depositar(valor);


  destino.saldo+=valor;
    
}

  


  
}
}
  