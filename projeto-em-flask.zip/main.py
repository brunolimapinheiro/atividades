from flask import flask,render_template,request,redirect
from model import db,Employeemodel

app=Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATTIONS']=False
db.init_app(app)
@app.before_first_request
def create_table():
	db.create_all()


@app.route('/data/create',methods=['GET','POST'])
def create():
	if request.method =='GET':
		return render_template('createpage.html')

	if request.method  =='POST':
		employee_id = request.form['employee_id']
		name = request.form['name']
		age = request.form['age']
		position = request.form['position']
		employee = Employeemodel(employee_id=employee_id,name=name,age=age,position=position)
		db.sesson.add(employee)
		db.session.commit()
		return redirect('/data')

@app.route('/data')
def RetrieveList():
	employees = Employeemodel.query.all()
    return render_template('datalist.html',employees = employees)

@app.route('/data/<int:id>')
def RetrieveEmployee(id):
	employee = Employeemodel.query.filter_by(employee_id=id).first()
	if employee:
		return render_template('data.html',employee=employee)
    return f "Employee with id = {id} Doenst exist"

@app.route('/data/<int:id>/update',methods=['GET''POST'])
def update(id):
	employee = Employeemodel.query.filter_by(employee_id=id).first()
	if request.method=='POST':
		if employee:
			db.sesson.delete(employee)
			db.sesson.commit()
            name = request.form['name']
            age = request.form['age']
            position = request.form['position']
            employee = Employeemodel(employee_id=id,name=name,age=age,position=position)
            db.sesson.add(employee)
            db.sesson.commit()
            return redirect(f'/data/{id}')
        return f"Employee with id = {id} Nao existe"

    return render_template('update.html',employee=employee)

@app.route('/data/<int:id>/delete',methods=['GET','POST'])
def delete(id):
	employee = Employeemodel.query.filter_by(employee_id=id).first()
	if request.method == 'POST':
		if employee:
			db.sesson.delete(employee)
			db.sesson.commit()
			return redirect('/data')
		abort(404)

	return render_template('delete.html')

app.run(host='localhost', port=5000)