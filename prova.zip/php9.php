
<?php
  if(isset($_POST["btnEnviar"])){
  echo "Nome:" . $_POST["nome"]."<br>";
  echo "Endereço:" . $_POST["endereco"]."<br>";
  echo "CEP:"  . $_POST["cep"]. "<br>";
  echo "Email:" . $_POST["email"]."<br>";
  echo "Data de Nascimento:" .$_POST["data"]."<br>";
  echo "Cidade:" . $_POST["cidade"]."<br>";
  echo "Estado:" . $_POST["estado"]."<br>";
  echo "Sexo:"  . $_POST["sexo"]."<br>";
  echo "Tipo Sanguineo:" . $_POST["tipo_d_sangue"];
  }  


?>
  
 