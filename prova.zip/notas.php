
 <?php
   if(isset($_POST["btEnviar"])){
    $soma=$_POST["1"]+ $_POST["2"]+$_POST["3"]+$_POST["4"];
    $media=$soma/4;
     echo "Informações:"."<br>";
     echo "Nome_disciplina: " .$_POST["disciplina"]."<br>";
     echo "professor: " .$_POST["professor"]."<br>";
     echo "carga_horaria: " .$_POST["carga"]."<br>";
     echo "periodo: ". $_POST["periodo"]."<br>";
     echo "suas Notas:" .$POST["1"]."<br>";
     echo $_POST["2"]."<br>";
     echo $_POST["3"]."<br>";
     echo $_POST["4"]."<br>";
     echo "MEDIA:".$media."<br>";
     
    if($media>=7){
      echo"Aprovado";
    }elseif($media<=4){
      echo"prova final";
    }
   }else{
     echo"reprovado";
   }



?>
  
 