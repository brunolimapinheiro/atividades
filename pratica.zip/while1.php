<?php
$c=0;
while($c<10){
  echo $c . "<br>";
  $c+=1;
}
$valor=$_POST["v1"];
echo $valor;


?>