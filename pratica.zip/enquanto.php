<html>
<head>
</head>
<body>
  <form action="while1.php" method="post">
  <?php
   $c=0;
   while($c<=5){
     echo "valor$c: <input type='number' name='v$c'>"."<br>";
     $c+=1;
   }
?>
  
  </form>



      
</body>

</html>