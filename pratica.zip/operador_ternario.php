<?php
$a=isset($_GET["ano"])?$_GET["ano"]:1900;
$i= date("Y")-$a;
echo "voce nasceu em $a e tem $i anos"."<br>";
if($i <16){
  echo "não vota";
}
else{
  if (($i>=16 && $i <18)||($i>65)){
    echo " voto opcional";
  }
  else{
    echo "voto obrigatorio";
  }
}




?>