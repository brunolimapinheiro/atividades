<?php
$l="leite";
$pr=4.50;
printf("o %s custa %.2f //", $l,$pr);
$v[0]=1;
$v[1]=2;
$v[2]=3;
print_r($v);
echo "//";
$v2=array(1,2,3,4,5,6);
print_r($v2);
echo "//";
$t="funções em php aula blalala e é isso kkk hahaha";
$r=wordwrap($t,2,"<br>");
echo $r;


?>