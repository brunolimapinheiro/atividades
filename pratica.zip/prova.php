<?php
  function 3mensagens() {
     for($i=1; $i<=3; $i++) { echo “Olá”; }
  }
  3mensagens();
?>
