<?php
$v= array("nome"=>"ana",
          "idade"=>"14",
          "peso"=>"50.0",
          "fuma"=>false);
foreach($v as $valor =>$campo){
  echo "<br>"." o valor de $valor é $campo ";
}
echo "<br>";
$arrai= array(array(3,4),
              array(5,9),
              array(7,9),
              array(1,0));
$m[0][1]=$m[2][0];
print_r($arrai);


?>