import java.util.ArrayList;
class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    ArrayList<String> lista = new ArrayList<String>();
    lista.add("abc");
    lista.add("def");
    //lista.remove(0);
    lista.size();
    System.out.println(lista.size());
    System.out.println(lista.get(0));

    
   }
}