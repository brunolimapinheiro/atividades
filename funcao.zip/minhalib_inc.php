<?php
function nota($n){
  if( $n>=70){
    return "aprovado";
  }
 elseif(($n<7) and ($n>=4)) {
  return "prova final";
}else{
  return "reprovado";
  }
}





?>