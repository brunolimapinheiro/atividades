<?php function qualitativo($m){
  if($m>=8){
    return 10;
  }else{
    return $m+2;
  }
}
?>