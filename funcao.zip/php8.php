<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php include("minhalib2_inc.php");
  ;$a=9;
   $x=qualitativo($a);
   echo "$x";?> 


  </body>
</html>