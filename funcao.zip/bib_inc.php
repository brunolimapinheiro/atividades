<?php
function soma($lista){
      $soma = 0;
      foreach($lista as $a){
        $soma=$soma+$a;
      }
  return $soma;
    } 





?>