<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php include("minhalib_inc.php");
  ;$a=7;
   $x=nota($a);
   echo "$x";?> 


  </body>
</html>