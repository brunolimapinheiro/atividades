<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php include("bib_inc.php");
  $a=[1,5,8,10,15];
  $x=soma($a);
  echo "$x";?> 


  </body>
</html>