<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
  <?php $pessoas = array("ruan","bruno","augusto","mateus","gustavo");
      foreach($pessoas as $a){
      echo $a, "<br>";
      } echo"terceiro_aluno=$pessoas[2]"; 
     $a=range(1,100);
     $b=range(1,100,2);
     $c=range(1,100,5);
      echo $a[2]?> 

   

  </body>
</html>