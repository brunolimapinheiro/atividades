    <?php $a=array("numeros"=>0,"final"=>100);
     asort($a);
     $b=range(1,100,2);
     $c=range(1,100,5);
      echo $a;?>