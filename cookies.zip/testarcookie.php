<?php
if(!isset($_COOKIE["curso"])){
echo "o cookie desejado não existe!";
} else{
  echo "seu curso é". $_COOKIE["curso"]. "!";
}
?>
