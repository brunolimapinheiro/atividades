<?php
setcookie("curso","ADS",time()+(30));

?>
<p><a href="testarcookie.php">testar o cookie criado</a></p>