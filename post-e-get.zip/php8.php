<html>
<head>
</head>
<body>

  <?php
  if(isset($_post["btnEnviar"])){
    echo "nome " .$post["nome"]."<br>";
    echo "cor".  $post["cor"]."<br>";
    echo "sexo". $post["sexo"]."<br>";
    echo "telefone". $post["telefone"]."<br>";
    echo "you win";
  }
  else{  
    <p>Cadastro de animais</p>
<form action="." method="post">
  Nome:<input type="text" name="nome">
  Cor: <input type="text" name= "cor"><br>
  Sexo:<br><input type="radio"name= "sexo" value ="macho">Macho<br>
  <input type="radio"name= "sexo" value ="femia">Femia<br>
   <input type="radio"name= "sexo" value ="outro">personalizado<br>
  telefone: <input type="text" name="telefone">
  Envio:<input type="submit"name="btnEnviar" value="Enviar">
  
</form>
   
  }
  
  ?>
</body>
</html>