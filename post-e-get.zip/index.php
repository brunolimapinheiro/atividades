
<?php 
  echo "o valor enviado foi:".$_GET["matricula"]; ?> 

  
  
 