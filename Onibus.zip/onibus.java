class Onibus{
  int passageiros;
  
  

  boolean acelerar( boolean movimento){
    movimento= true;
    return boolean;
    
  }
  boolean parar(boolean movimento){
    movimento=false;
    return boolean;
  }
  int tirar(int quantidade){
    passageiros-=quantidade;
    return passageiros;
}
    
 int adicionar(int quantidade){
   passageiros+=quantidade;
   return passageiros;
 }
  
}