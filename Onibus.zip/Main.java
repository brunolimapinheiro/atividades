class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    Onibus onibus1= new Onibus();
    onibus1.acelerar(boolean aceleraAi);
    onibus.parar(boolean paraAi);
    if(aceleraAi){
      System.out.println("acelerando");
    }else{
      System.out.println(" ");
    }

   if (paraAi){
  System.out.println("parado");

} else{
     System.out.println(" ");
}
    
  }
}