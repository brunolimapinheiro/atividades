<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
  <?php 
   require "conecta-inc.php";
    
?> 

   
  </body>
</html>