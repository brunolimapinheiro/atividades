<?php
include("conecta-inc.php"); //usamos nossa conexão
$sql = "SELECT id, titulo, genero FROM jogos"; //criamos uma query
$result = $conn->query($sql); //executamos a query no objeto de conexão
if ($result->num_rows > 0) {
// monta os dados de saída linha a linha
while($row = $result->fetch_assoc()) {
echo "id: " . $row["id"]. " - Titulo: " . $row["titulo"]. " " . $row["genero"]. "<br>";
} //fim do while
} else {
echo "0 results"; //Caso o select não retorne resultados
}
$conn->close(); //fecha a conexão no corpo da página, já que temos uma verificação dentro do include
?>