<?php
$servername = "sql10.freesqldatabase.com";
$username = "sql10579530";
$password = "ts5V7qhIWw";
$dbname = "sql10579530";
// Cria uma conexão com as credenciais, note que não estamos fechando a mesma
$conn = new mysqli($servername, $username, $password, $dbname);
//O trecho abaixo verifica se existem erros, compatível com PHP >= 5.3
if ($conn->connect_error) {
die("Connection failed: " . $conn->connect_error); //encerra o script por completo
}
//echo "Connected successfully"; //o código daqui em diante só executa se a conexão estiver OK...
?>
