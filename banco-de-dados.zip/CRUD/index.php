<html>
  <head><title>Sistema de gerênciamento de Jogos</title></head>
  <body>
  <h3>Listagem de jogos</h3>
  <a href="create-update.php">Clique aqui para adicionar</a> <br>
<?php
  include("../conecta-inc.php"); //usamos o arquivo de conexão que esta na raiz do projeto
  $sql = "SELECT id, titulo, genero FROM jogos"; //criamos uma query
  $result = $conn->query($sql); //executamos a query no objeto de conexão
  //criamos o cabeçalho da tabela e os  textos do header antes do loop 
  echo '<table border="1">'; //abre a tabela
         echo "<tr>"; //linha
         echo "<th>#ID</th>"; //item
         echo "<th>Título</th>"; //item
         echo "<th>Gênero</th>"; //item
         echo "<th>Ver detalhes</th>"; //item
         echo "<th>Editar</th>"; //item
         echo "<th>Remover</th>"; //item
         echo "</tr>"; //fecha a linha                               
  if ($result->num_rows > 0) { //verifica se não existem resultados
    // monta os dados <td> de saída linha <tr> a linha <tr> na tabela
  while($row = $result->fetch_assoc()) {
    echo "<tr>"; //inicio da linha
       echo "<td>" . $row["id"] . "</td>"; //item
       echo "<td>" . $row["titulo"] . "</td>"; //item
       echo "<td>" . $row["genero"] . "</td>"; //item
       echo "<td>" . '<a href="detalhes.php?id=' . $row['id'] . '">Vizualizar</a>' . "</td>"; //item
       echo "<td>" . '<a href="create-update.php?id=' . $row['id'] . '">Atualizar</a>' . "</td>"; //item
       echo "<td>" . '<a href="remove.php?id=' . $row['id'] . '">Remover</a>' . "</td>"; //item
    echo "</tr>"; //fim de linha
        } //fim do while
     } else { //else do if
    echo "<tr>";
         echo "<td colspan='6'>Não foram encontrados resultados</td>"; //Caso o select não retorne resultados
    echo "</tr>";
   } //fim do else
  echo '</table>'; //fecha a tabela fora das checagens
  $conn->close(); //fecha a conexão no corpo da página, já que temos uma verificação dentro do include
?> 
  </body>
</html>