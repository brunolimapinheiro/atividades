<?php
  include("../conecta-inc.php");
  
  if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    $id = trim($_GET["id"]); //trata e armazena o parâmetro
    $sql = "SELECT * FROM jogos WHERE id = $id";
    $result = $conn->query($sql);
    if ($result->num_rows == 1) {
      $row = $result->fetch_assoc();
      $num_jogador = $row["num_jogador"];
      $plataforma = $row["plataforma"];
      $sinopse = $row["sinopse"];
      $tipo_midia = $row["tipo_midia"];
      $titulo = $row["titulo"];
      $genero = $row["genero"];
      $data_aquisicao = $row["data_aquisicao"];
    
      } else { //else do if num_rows
        echo "A consulta retornou mais de um registro!";
    }//fim do else 
  } //fim dos if isset
  $conn->close();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Detalhes</title>
</head>
<body>
<h3>Detalhes do Jogo</h3>
<a href="index.php">Retornar para página inicial</a> </br>
<label><b>Título: </b></label><p><?php echo $titulo; ?></p>
<label><b>Plataforma: </b></label><p><?php echo $plataforma; ?></p>
<label><b>Gênero: </b></label><p><?php echo $genero; ?></p>
<label><b>Tipo de mídia: </b></label><p><?php echo $tipo_midia; ?></p>
<label><b>Número de jogadores: </b></label><p><?php echo $num_jogador; ?></p>
<label><b>Data de aquisição: </b></label><p><?php echo $data_aquisicao; ?></p>
<label><b>Sinopse: </b></label><p><?php echo $sinopse; ?></p>
</body>
</html>