<html>
  <head><title>Seus Contatos</title></head>
  <body>
  <h3>Contatos</h3>
  <a href="create-update.php">Clique aqui para adicionar</a> <br>
<?php
  include("../conecta-inc.php"); 
  $sql = "SELECT id, titulo, genero FROM contatos";
  $result = $conn->query($sql); 
  echo '<table border="1">';
         echo "<tr>";
         echo "<th>#ID</th>"; 
         echo "<th>Nome</th>"; 
         echo "<th>Endereço</th>"; 
         echo "<th>Ver detalhes</th>"; 
         echo "<th>Editar</th>"; 
         echo "<th>Remover</th>"; 
         echo "</tr>";                               
  if ($result->num_rows > 0) { 
  while($row = $result->fetch_assoc()) {
    echo "<tr>"; //inicio da linha
       echo "<td>" . $row["id"] . "</td>"; //item
       echo "<td>" . $row["nome"] . "</td>"; //item
       echo "<td>" . $row["endereco"] . "</td>"; //item
       echo "<td>" . '<a href="detalhes.php?id=' . $row['id'] . '">Vizualizar</a>' . "</td>"; //item
       echo "<td>" . '<a href="create-update.php?id=' . $row['id'] . '">Atualizar</a>' . "</td>"; //item
       echo "<td>" . '<a href="remove.php?id=' . $row['id'] . '">Remover</a>' . "</td>"; //item
    echo "</tr>"; //fim de linha
        } //fim do while
     } else { //else do if
    echo "<tr>";
         echo "<td colspan='6'>Não foram encontrados resultados</td>"; //Caso o select não retorne resultados
    echo "</tr>";
   } //fim do else
  echo '</table>'; //fecha a tabela fora das checagens
  $conn->close(); //fecha a conexão no corpo da página, já que temos uma verificação dentro do include
?> 
  </body>
</html>