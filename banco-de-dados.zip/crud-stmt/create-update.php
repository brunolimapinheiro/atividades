<?php
include("../conecta-inc.php");


$id = $nome=$endereco=$telefone=$rede_social=$data_nascimento=$e_mail=$contato_emegencia="";

if(isset($_POST["id"]) && !empty($_POST["id"])){
  $id = $_POST["id"];
  $nome = trim($_POST["nome"]);
  $endereco = trim($_POST["endereco"]);
  $telefone = trim($_POST["telefone"]);
  $rede_social = trim($_POST["rede_social"]);
  $data_nascimento = trim($_POST["data_nascimento"]);
  $e_mail = trim($_POST["genero"]);
  $contato_emegencia = trim($_POST["contato_emegencia"]);
  $stmt =$conn->prepare("UPDATE contatos SET nome= ?, endereco = ?, telefone = ?, rede_social= ?, data_nascimento= ?, e_mail = ?, contato_emegencia=? WHERE id=?");
  $stmt->param("issssi",$nome,$endereco,$telefone,$rede_social,$data_nascimento,$e_mail,$contato_emegencia,$id);
  $stmt->execute();

  if ($stmt >affected_rows >0) {
      $stmt->close();
      $conn->close();
      header("location: index.php");
      exit();
  } else {
    echo "Error updating record: " . $conn->error;
    $stmt->close();
    $conn->close(); 
    } 


} elseif (isset($_GET["id"]) && !empty($_GET["id"])) {
$id = trim($_GET["id"]);
$stmt =$conn->prepare("SELECT * FROM jogos WHERE id = ?");
$stmt->param("i",$id);
$result = $stmt->get_result();
if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    $nome = $row["nome"];
    $endereco = $row["endereco"];
    $telefone = $row["telefone"];
    $rede_social = $row["rede_social"];
    $data_nascimento = $row["data_nascimento"];
    $e_mail = $row["e_mail"];
    $contato_emegencia = $row["contato_emegencia"];
     } else {
       echo "Erro fatal, mais de um registro encontrado na consulta.";
      }
$stmt->close();
$conn->close();
} 
elseif ($_SERVER["REQUEST_METHOD"] == "POST" && empty($_POST["id"])) { 
  $nome = trim($_POST["nome"]);
  $endereco = trim($_POST["endereco"]);
  $telefone = trim($_POST["telefone"]);
  $rede_social = trim($_POST["rede_social"]);
  $data_nascimento = trim($_POST["data_nascimento"]);
  $e_mail = trim($_POST["e_mail"]);
  $contato_emegencia = trim($_POST["contato_emegencia"]);

  $stmt =$conn->prepare("INSERT INTO contatos (nome, endereco, telefone, rede_social, data_nascimento, e_mail, contato_emegencia) VALUES (?,?,?,?,?,?,?)");
  $stmt->bind_param("issssss",$nome,$endereco,$telefone,$rede_social,$data_nascimento,$e_mail,$contato_emegencia);
  $stmt->execute();
    
  if ($stmt->affected_rows >0) {
      $stmt->close();
      $conn->close(); 
      header("location: index.php");
      exit();
  } else {
    echo "Erro ao inserir o registro: " . $conn->error;
    $stmt->close();
    $conn->close();
    } 


} 
?>

<!DOCTYPE html>
<html>
<head>
  <title>Create/Update Record - Statements</title>
</head>
<body>
<h3>Cadastrar/Atualizar Contatos</h3>
<form action="create-update.php" method="POST">
<a href="index.php">Cancelar e retornar para página inicial</a> </br>
<input type="hidden" name="id" value="<?php echo $id; ?>"/>
<label>Nome:</label><input type="text" name="titulo" value="<?php echo $nome; ?>"> </br>
<label>Endereco:</label><input type="text" name="plataforma" value="<?php echo $endereco; ?>"> </br>
<label>Telefone:</label><input type="text" name="genero" value="<?php echo $Telefone; ?>"> </br>
<label>Rede Social:</label><input type="text" name="tipo_midia" value="<?php echo $rede_social; ?>"> </br>
<label>Data de Nascimento:</label><input type="text" name="data_aquisicao" value="<?php echo $data_nascimento; ?>"> </br>
<label>E-mail:</label><input type="text" name="num_jogador" value="<?php echo $e_mail; ?>"> </br>
<label>Contato De Emegência:</label> <textarea name="sinopse" rows="10" cols="50"> <?php echo $contato_emegencia; ?> </textarea> </br>
<input type="submit" value="Submit"> </br>
</form>
</body>
</html>
