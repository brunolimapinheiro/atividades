<?php
include("../conecta-inc.php");

if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
  $id = trim($_GET["id"]); 
  $stmt=$conn->prepare("DELETE FROM contatos WHERE id=?");
  $stmt->bind_param("i",$id);
  $stmt->execute();
  if ($stmt->affected_rows >0 {
    echo "registro excluido com sucesso";
      
      
    } else {
      echo "Ocorreu um erro o executar o comando!";
     
} 
}
$stmt->close();
$conn->close();
header("location: index.php");
exit();
?>