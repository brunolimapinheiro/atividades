<?php
  include("../conecta-inc.php");
  
  if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
    $id = trim($_GET["id"]); 
    $stmt=$conn->prepare("SELECT * FROM contatos WHERE id = ?");
    $stmt->bind_param("1",$_GET["id"]);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows == 1) {
      $row = $result->fetch_assoc();
      $nome = $row["nome"];
      $endereco = $row["endereço"];
      $telefone = $row["telefone"];
      $rede_social = $row["rede_social"];
      $data_nascimento = $row["data_nascimento"];
      $e_mail = $row["e-mail"];
      $contato_emegencia = $row["contato_emegencia"];
    
      } else { //else do if num_rows
        echo "A consulta retornou mais de um registro!";
    }//fim do else 
  } //fim dos if isset
  $stmt->close();
  $conn->close();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Detalhes</title>
</head>
<body>
<h3>Contatos</h3>
<a href="index.php">Retornar para página inicial</a> </br>
<label><b>Nome: </b></label><p><?php echo $nome; ?></p>
<label><b>Endereço: </b></label><p><?php echo $endereco; ?></p>
<label><b>Telefone: </b></label><p><?php echo $telefone; ?></p>
<label><b>Rede Social: </b></label><p><?php echo $rede_social; ?></p>
<label><b>Data De Nascimento: </b></label><p><?php echo $data_nascimento; ?></p>
<label><b>E-mai: </b></label><p><?php echo $e_mail; ?></p>
<label><b>Contato EmegenciaL: </b></label><p><?php echo $contato_emegencia; ?></p>
</body>
</html>