<?php
class Empregado{
  private $nome;
  public function getNome(){
    return $this->nome;
  }
public function setNome($nome){
  $this->nome=$nome;
}
}
$empregado = new Empregado();
$empregado->setNome("bruno");
echo $empregado->getNome();


?>