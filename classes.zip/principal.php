<?php
$nome=$_POST["nome"];
$elemento=$_POST["elemento"];
$forca=$_POST["forca"];
$vida=$_POST["vida"];
$magia=$_POST["magia"];
$ataquePrincipal=$_POST["ataquePrincipal"];

include "classe-inc.php";
$personagem = new Personagem($nome,$elemento,$forca,$vida,$magia,$ataquePrincipal);
echo $personagem->nome ."<br>";
echo $personagem->elemento ."<br>";
echo $personagem->forca . "<br>";
echo $perrsonagem->vida . "<br>";
echo $personagem->magia . "<br>";
echo $personagem->ataquePrincipal . "<br>";




?>