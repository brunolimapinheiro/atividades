<?php
  class Personagem{
  public $nome;
  public $elemento;
  public $forca;
  public $vida;
  public $magia;
  public $ataquePrincipal;
   
  public function Personagem($nome="",$elemento="",$forca=0,$vida="",$magia=0,$ataquePrincipal=""){
     $this->nome=$nome;
     $this->elemento=$elemento;
     $this->forca=$forca;
     $this->vida=$vida;
     $this->magia=$magia;
     $this->ataquePrincipal=$ataquePrincipal;
   
   
     
   }
  
  
}




?>