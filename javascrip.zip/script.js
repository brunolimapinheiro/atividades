var n1=56.8;
var n2=55.1;
alert(Math.pow(n1,2));
alert(Math.pow(n2,2));