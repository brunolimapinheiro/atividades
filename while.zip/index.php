<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php $c=0;
          while($c<=110){
          echo "$c <br>"; $c=$c+10;
          }
          for($c=0; $c<=110; $c=$c+10) {
            echo "$c <br>";
            $c=110;
          } do{
          echo "$c <br>"; $c=$c-10;}
            while($c>=0);
              ?> 
          
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
  </body>
</html>