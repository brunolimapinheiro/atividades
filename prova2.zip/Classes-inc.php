<html>
<head>
<link hred="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
<link href="estilo.css" rel="stylesheet" type="text/css">
</head>
<body>

<?php 
  // Letra A----------------------------------------------------------------------------

if(isset($_POST["btn"])){
include "Npc.php";
$nome=$_POST["nome"];
$raca=$_POST["raca"];
$vida=$_POST["vida"];
$elemento=$_POST["elemento"];
$magia=$_POST["magia"];
$forca=$_POST["forca"];
$bolsaDeEquipamentos=$_POST["equipamentos"];

$personagem=new Npc();

$personagem->setNome($nome);
$personagem->setRaca($raca);
$personagem->setVida($vida);
$personagem->setElemento($elemento);
$personagem->setMagia($magia);
$personagem->setForca($forca);
$personagem->setBolsaDeEquipamentos($bolsaDeEquipamentos);

echo "nome:" .$personagem->getNome()."<br>";
echo "raça:" .$personagem->getRaca()."<br>";
echo "vida:". $personagem->getVida()."<br>";
echo "elemento:" . $personagem->getElemento()."<br>";
echo "magia:" . $personagem->getMagia()."<br>";
echo "força:" . $personagem->getForca()."<br>";
echo "bolsa de equipamentos";
foreach ($personagem->getBolsaDeEquipamentos() as $i){
    
  echo  $i . "<br>";}

}

 // Letra B----------------------------------------------------------------------------

if(isset($_POST["btn1"])){
include "Boss.php";
$nome=$_POST["nome2"];
$defesa=$_POST["defesa"];
$vida=$_POST["vida2"];
$elemento=$_POST["elemento2"];
$magia=$_POST["magia2"];
$nivel=$_POST["nivel"];

$boss=new Boss();

$boss->setNome($nome);
$boss->setDefesa($defesa);
$boss->setVida($vida);
$boss->setElemento($elemento);
$boss->setMagia($magia);
$boss->setNivel($nivel);

echo "Nome:" . $boss->getNome()."<br>";
echo "defesa:" . $boss->getDefesa()."<br>";
echo "vida:" . $boss->getVida()."<br>";
echo "elemento:" .$boss->getElemento()."<br>";
echo "magia:" . $boss->getMagia()."<br>";
echo "nivel:" .$boss->getNivel()."<br>";

}

  




  // Letra C----------------------------------------------------------------------------
if(isset($_POST["btn2"])){
  include "SalaDeAula.php";
  $local=$_POST["local"];
  $capacidadeTotal=$_POST["capacidade_total"];
  $locaisOcupados=$_POST["locais_ocupados"];
  
  $sala=new SalaDeAula();

  $sala->setLocal($local);
  $sala->setCapacidadeTotal($capacidadeTotal);
  $sala->setLocaisOcupados($locaisOcupados);
  if($sala->ocuparLugares() <0){
    echo "valor invalido";
  }
  if($sala->ocuparLugares()>=0){
      echo "vagas disponiveis"."<br>";
      echo  $sala->ocuparLugares();
 
}
}


?>
</body>
</html>