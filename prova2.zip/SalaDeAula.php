<?php
class SalaDeAula{
  private $local;
  private $capacidadeTotal;
  private $locaisOcupados;

  public function SalaDeAula($local="",$capacidadeTotal=0,$locaisOcupados=0){
    $this->local=$local;
    $this->capacidadeTotal=$capacidadeTotal;
    $this->localOcupados=$localOcupados;
  }

public function setLocal($local){
  $this->local=$local;
}
public function getLocal(){
  return $this->local;
}
  public function setCapacidadeTotal($capacidadeTotal){
  $this->capacidadeTotal=$capacidadeTotal;
}
public function getCapacidadeTotal(){
  return $this->capacidadeTotal;
}

  public function setLocaisOcupados($locaisOcupados){
  $this->locaisOcupados=$locaisOcupados;
}
public function getLocaisOcupados(){
  return $this->locaisOcupados;
}
public function ocuparLugares(){
  return $this->getCapacidadeTotal() - $this->getLocaisOcupados();
   }
}
  

?>