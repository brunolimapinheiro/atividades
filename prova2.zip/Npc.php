<?php
class Npc{
private $nome;
private $raca;
private $vida;
private $elemento;
private $magia;
private $forca;
private $bolsaDeEquipamentos;

public function Personagem($nome="",$raca="",$vida=0,$elemento="",$magia="",$forca=0, $bolsaDeEquipamentos=""){
$this->setNome($nome);
$this->setRaca($raca);
$this->setVida($vida);
$this->setElemento($elemento);
$this->setMagia($magia);
$this->setForca($forca);
$this->setBolsaDeEquipamentos($bolsaDeEquipamentos);
}
public function getNome(){
  return $this->nome;
}
public function setNome($nome){
  $this->nome=$nome;
}
public function getRaca(){
  return $this->raca;
}
public function setRaca($raca){
  $this->raca=$raca;
}
public function getVida(){
  return $this->vida;
}
public function setVida($vida){
  $this->vida=$vida;
}
public function getElemento(){
  return $this->elemento;
}
public function setElemento($elemento){
  $this->elemento=$elemento;
}
public function getMagia(){
  return $this->magia;
}
public function setMagia($magia){
  $this->magia=$magia;
}
public function getForca(){
  return $this->forca;
}
public function setForca($forca){
  $this->forca=$forca;
}

public function getBolsaDeEquipamentos(){
  return $this->bolsaDeEquipamentos;
}
public function setBolsaDeEquipamentos($bolsaDeEquipamentos){
  $this->bolsaDeEquipamentos=$bolsaDeEquipamentos;
}

}






?>