<?php
include "Npc.php";
class Boss extends Npc{
 private $defesa;
 private $nivel;

public function Boss($defesa=0,$nivel=0) {
  $this->defesa=$defesa;
  $this->nivel=$nivel;
} 
  
public function getDefesa(){
  return $this->defesa;
}
public function setDefesa($defesa){
  $this->defesa=$defesa;
}
public function getNivel(){
  return $this->nivel;
} 
public function setNivel($nivel){
  $this->nivel=$nivel;
}
  
}





?>