<?php
$senha = “1234”;
$m = md5($senha);
$sh = sha1($senha);
echo "Hash para senha $senha = " . $m . " no formato md5 <br>";
echo "Hash para senha $senha = ". $sh . " no formato sha1";
?>