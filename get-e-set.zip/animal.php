<?php
class animal{
private $nome;
private $tamanho;
private $idade;
private $cor;
private $peso;

public function Animal($nome="",$tamanho="",$idade=0,$cor="",$peso=0){
  $this->nome=$nome;
  $this->tamanho=$tamanho;
  $this->idade=$idade;
  $this->cor=$cor;
  $this->peso=$peso;
}
  
public function setNome($nome){
  $this->nome=$nome;
}
public function getNome(){
  return $this->nome;
}
public function setTamanho($tamanho){
  $this->tamanho=$tamanho;
} 
public function getTamanho(){
  return $this->tamanho;
}
public function setIdade($idade){
  $this->idade=$idade;
}
public function getIdade(){
  return $this->idade;
}
public function setCor($cor){
  $this->cor=$cor;
}
public function getCor(){
  return $this->cor;
}
public function setPeso($peso){
  $this->peso=$peso;
}
public function getPeso(){
  return $this->peso;
}

}





?>