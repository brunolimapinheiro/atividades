<?php
include "animal.php";
$nome=$_POST["nome"];
$tamanho=$_POST["tamanho"];
$idade=$_POST["idade"];
$cor=$_POST["cor"];
$peso=$_POST["peso"];

$pet=new Animal();
$pet->setNome($nome);
$pet->setTamanho($tamanho);
$pet->setIdade($idade);
$pet->setCor($cor);
$pet->setPeso($peso);

echo $pet->getNome()."<br>";
echo $pet->getTamanho()."<br>";
echo $pet->getIdade()."<br>";
echo $pet->getCor()."<br>";
echo $pet->getPeso()."<br>";





?>