
    <?php $a=10; 
          $b=15;
          $result=$a+$b;
          $result1=$a-$b;
          $result2=$a*$b;
          $result3=$a/$b;
          echo "o resultado foi $result". "<br>";
          echo "o resultado foi $result1". "<br>" ;
      
          echo "o resultado foi $result2". "<br>";
          echo "o resultado foi $result3". "<br>";?> 


