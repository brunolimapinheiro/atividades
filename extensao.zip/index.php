<?php 
     phpinfo();


?> 

