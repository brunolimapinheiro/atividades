
<?php
$i="terça";
if($i=="segunda"){
  echo "aula 1";
}elseif($i=="terça"){
  echo "aula 2";
}elseif($i=="quarta"){
  echo "aula 3";
}elseif($i=="quinta"){
  echo "aula 4";
}elseif($i=="sexta"){
  echo "aula 5";
}
switch ($i) {
    case "segunda":
        echo "aula 1";
        break;
    case "terça":
        echo " aula 2";
        break;
    case "quarta":
        echo "aula 3";
        break;
    case "quinta":
        echo "aula 4";
        break;
    case "sexta":
        echo "aula 5";
        break;
}
?>
