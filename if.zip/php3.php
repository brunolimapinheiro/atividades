<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php $a= 10.0;
          $b=10;
          $c="10";
          if ($a===$b){
            echo "são iguais";
            echo gettype($a);
            echo gettype($b);
        
          }elseif($a===$c){
            echo "camp2 são iguais";
          } "<br>"elseif($b===$c){
            echo "camp4 são iguais";
            }else{
            echo "são diferentes";
            echo gettype($a);
            echo gettype($b);
            echo gettype($c);
            }
           ?> 


    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
  </body>
</html>