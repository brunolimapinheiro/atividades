import java.util.ArrayList;
class Livro{
String titulo;
int ano_d_public;
ArrayList<String> genero=new ArrayList<String>();
ArrayList<Autor> autor= new ArrayList<Autor>();


  
}