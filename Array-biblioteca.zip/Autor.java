
class Autor{
  String nome;
  String cidade;
  int ano_d_nasc;
  


  
}