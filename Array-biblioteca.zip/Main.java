import java.util.ArrayList;
class Main {
  public static void main(String[] args) {
    Livro livro=new Livro();
    livro.autor=new Autor();
    Autor autor=livro.autor;
    livro.autor="desconhecido";
    livro.ano_d_public=2001;
    livro.genero.add("terror");
    livro.genero.add("comedia");

  
    
  }
}