<html>
  <head>
    <title>PHP Test</title>
  </head>
  <body>
    <?php $a=6.5;
          $b=8.0;
          $result=($a+$b)/2;
          echo ($result>= 7.0?"Aprovado":"reprovado"); ?>

  </body>
</html>